#include <iostream>
#include "housingq.h"
using namespace std;

int main()
{
    HousingQ hque;

    hque.run();

    return 0;
}
