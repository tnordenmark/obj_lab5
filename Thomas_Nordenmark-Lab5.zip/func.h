#ifndef FUNC_H
#define FUNC_H
#include "person.h"

void invalidChoice();

#endif // FUNC_H
