#ifndef FUNC_H
#define FUNC_H
#include "person.h"

void invalidChoice();
void printPers(Person const &p);

#endif // FUNC_H
